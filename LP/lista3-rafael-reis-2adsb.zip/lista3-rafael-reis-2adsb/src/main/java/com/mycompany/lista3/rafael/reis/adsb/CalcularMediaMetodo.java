package com.mycompany.lista3.rafael.reis.adsb;

public class CalcularMediaMetodo {

    Double calcularMedia(Double num1, Double num2) {

        return num1 * .4 + num2 * 0.6;

    }
}
