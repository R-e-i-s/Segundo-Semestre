package com.sptech.projeto.lista.desafio;

import java.util.List;

public class ListaUtil {
    
    private List<Integer> inteiros;

    public ListaUtil() {

    }

    public void add(Integer valor) {
        
    }

    public void remove(Integer valor) {
       
    }

    public Integer count() {
        return null;
    }

    public Integer countPares() {
        return null;
    }

    public Integer countImpares() {
        return null;              
    }

    public Integer somar() {
        return null;    
    }

    public Integer getMaior() {
       return null;
    }

    public Integer getMenor() {
        return null;
    }

    public Boolean hasDuplicidade() {
        return null;
    }
}
