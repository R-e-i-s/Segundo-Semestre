/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lista02;

/**
 *
 * @author rafael.reis
 */
public class ContadorVariado {

    public static void main(String[] args) {

        for (double i = 0.15; i < 5; i += 0.15) {
            System.out.println(String.format("%.2f", i));
        }

    }
}
